// Tiny VN engine (English version)
const $ = (q) => document.querySelector(q);
const namebox = $("#namebox");
const textbox = $("#textbox");
const sprite = $("#sprite");
const choicesBox = $("#choices");
const bg = $("#bg");

const SAVE_KEY = "mahiru_demo_save_v1_en";

// Scenes
const scenes = {
  start: [
    { bg: "evening", s: "System", t: "Welcome to the Mahiru Fan Game Demo — Unofficial project." },
    { s: "Mahiru", face: "neutral", t: "Um… hello. I’m Shiina Mahiru. Nice to meet you." },
    { s: "Player", t: "Hi, Mahiru. Sorry for calling you out to the balcony this evening." },
    { s: "Mahiru", face: "shy", t: "It’s okay. The breeze feels nice… By the way, did you want to talk about something?" },
    { choice: [
      { text: "Thank you for the sweets you made yesterday", to: "thanks" },
      { text: "Want to study together?", to: "study" }
    ]}
  ],
  thanks: [
    { s: "Player", t: "Thanks for the cookies yesterday. They were delicious." },
    { s: "Mahiru", face: "happy", t: "I’m glad you liked them. I was trying out a new recipe." },
    { s: "Player", t: "Maybe you could teach me sometime." },
    { s: "Mahiru", face: "neutral", t: "Of course. How about this weekend?" },
    { choice: [
      { text: "Sure! See you then.", to: "good_end" },
      { text: "Let me think about it.", to: "neutral_end" }
    ]}
  ],
  study: [
    { s: "Player", t: "We have a test tomorrow… Could you help me review a bit?" },
    { s: "Mahiru", face: "serious", t: "Sure. Let’s start with the parts you’re unsure about." },
    { s: "Player", t: "The equations… those are tough." },
    { s: "Mahiru", face: "happy", t: "They’re not too bad. We’ll go step by step together." },
    { choice: [
      { text: "Thanks! I’m ready.", to: "good_end" },
      { text: "Maybe another time…", to: "bad_end" }
    ]}
  ],
  good_end: [
    { s: "Mahiru", face: "happy", t: "Great! Then, see you soon." },
    { s: "System", t: "Ending: Evening Breeze — Your bond has grown closer." },
    { end: true }
  ],
  neutral_end: [
    { s: "Mahiru", face: "neutral", t: "I understand. Just tell me when you’re ready." },
    { s: "System", t: "Ending: Ordinary Day — Your relationship stays the same." },
    { end: true }
  ],
  bad_end: [
    { s: "Mahiru", face: "shy", t: "Okay… maybe next time." },
    { s: "System", t: "Ending: Missed Moment — You put things off for later." },
    { end: true }
  ]
};

let state = { scene: "start", index: 0 };

function setBG(style) {
  if (style === "evening") {
    bg.style.background = "radial-gradient(80% 60% at 50% 40%, #3a5670, #0f1522 70%)";
  } else {
    bg.style.background = "radial-gradient(80% 60% at 50% 40%, #2a415a, #101826 70%)";
  }
}

function renderLine() {
  const scene = scenes[state.scene];
  if (!scene) return;
  if (state.index >= scene.length) return;

  const line = scene[state.index];

  if (line.bg) setBG(line.bg);

  if (line.end) {
    namebox.textContent = "System";
    textbox.textContent = "Thanks for playing the demo! Press Reset to start again, or Save/Load to manage your progress.";
    choicesBox.classList.add("hidden");
    return;
  }

  if (line.choice) {
    namebox.textContent = "Choose";
    textbox.textContent = "Make your choice:";
    renderChoices(line.choice);
    return;
  }

  choicesBox.classList.add("hidden");
  namebox.textContent = line.s || "";
  textbox.textContent = line.t || "";

  if (line.face) {
    sprite.classList.remove("neutral","happy","shy","serious");
    sprite.classList.add(line.face);
  }
}

function renderChoices(options) {
  choicesBox.innerHTML = "";
  choicesBox.classList.remove("hidden");
  options.forEach(opt => {
    const btn = document.createElement("button");
    btn.className = "choice";
    btn.textContent = opt.text;
    btn.addEventListener("click", () => {
      state.scene = opt.to;
      state.index = 0;
      renderLine();
    });
    choicesBox.appendChild(btn);
  });
}

$("#textbox").addEventListener("click", next);
$("#stage").addEventListener("click", (e) => {
  if (e.target.classList.contains("choice")) return;
  next();
});
function next() {
  const scene = scenes[state.scene];
  if (!scene) return;
  const line = scene[state.index];
  if (line && line.choice) return;
  if (line && line.end) return;
  state.index = Math.min(state.index + 1, scene.length - 1);
  renderLine();
}

$("#btnSkip").addEventListener("click", () => {
  const scene = scenes[state.scene];
  for (let i = state.index; i < scene.length; i++) {
    if (scene[i].choice || scene[i].end) { state.index = i; break; }
  }
  renderLine();
});
$("#btnSave").addEventListener("click", () => {
  localStorage.setItem(SAVE_KEY, JSON.stringify(state));
  flash("Saved!");
});
$("#btnLoad").addEventListener("click", () => {
  const raw = localStorage.getItem(SAVE_KEY);
  if (!raw) { flash("No save data."); return; }
  try {
    state = JSON.parse(raw);
    renderLine();
    flash("Loaded!");
  } catch {
    flash("Load failed.");
  }
});
$("#btnReset").addEventListener("click", () => {
  state = { scene: "start", index: 0 };
  setBG("evening");
  sprite.classList.remove("happy","shy","serious"); sprite.classList.add("neutral");
  renderLine();
});

function flash(msg) {
  let el = document.createElement("div");
  el.textContent = msg;
  el.style.position = "absolute";
  el.style.left = "50%";
  el.style.bottom = "110px";
  el.style.transform = "translateX(-50%)";
  el.style.padding = "8px 12px";
  el.style.background = "rgba(0,0,0,.7)";
  el.style.border = "1px solid rgba(255,255,255,.2)";
  el.style.borderRadius = "8px";
  el.style.pointerEvents = "none";
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 1200);
}

setBG("evening");
renderLine();
